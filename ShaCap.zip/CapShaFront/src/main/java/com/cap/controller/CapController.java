package com.cap.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cap.model.Inventory;
import com.cap.model.Transaction;


@Controller
public class CapController {
	
	Transaction transaction;
	@RequestMapping("/home")
	public String getTransactionPage(ModelMap map) {
		if(transaction==null) {
			map.put("transaction", null);
		}
		else{
			map.put("transaction", transaction);
		}
		return "TransactionStatus";
	}
	
	
	@RequestMapping("/buyNow")
	public String navigateToShippingDetailsPage() {
		final String uri="http://localhost:8083//CapShaBackrest/api/v1";
		RestTemplate restTemplate=new RestTemplate();
		
		return "shippingAddress";
	}
	
	
	@RequestMapping("/addToCart")
	public String navigateToCartPage() {
		final String uri="http://localhost:8083//CapShaBackrest/api/v1";
		RestTemplate restTemplate=new RestTemplate();
		
		return "index";
	}
	
	@RequestMapping("/remove")
	public String removeItemFromCart() {
		final String uri="http://localhost:8083//CapShaBackrest/api/v1";
		RestTemplate restTemplate=new RestTemplate();
		
		return "index";	
	}
	
	@RequestMapping("/CheckOut")
	public String proceedFromCart() {
		final String uri="http://localhost:8083//CapShaBackrest/api/v1";
		RestTemplate restTemplate=new RestTemplate();
		
		return "ShippingAddress";	
	}	
	
	@RequestMapping("/ContinueShopping")
	public String continueShopping() {
		
		return "ProductPage";
	}
}
	
