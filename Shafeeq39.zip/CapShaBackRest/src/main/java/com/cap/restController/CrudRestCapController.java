package com.cap.restController;


import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cap.model.Inventory;
import com.cap.model.ManagingCart;
import com.cap.model.Order;
import com.cap.model.Transaction;
import com.cap.restService.IRestService;



@RestController
@RequestMapping("/api/v1")
public class CrudRestCapController {
	@Autowired
	private IRestService restService;

	

	/*@PostMapping("/buyNow")
	public String showDetails1(@PathVariable("quantity") Integer quantity) {
		Order order=new Order();
		product.setQuantity(quantity);
		order.setOrderDate(new Date());
		return "shippingAddressCap";
}
	
	@PostMapping("/addToCart")
	public String showDetails2(@PathVariable("quantity") Integer quantity) {
		Order order=new Order();
		product.setQuantity(quantity);
		order.setOrderDate(new Date());
		return "shippingAddressCap";
}

	@DeleteMapping("/remove/{productId}")
	public String removeItemFromCart(@PathVariable("productId") Integer productId) {
	restService.deleteItem(productId);
		return "index";	
	}*/
	
	







//PRIOR TO PLACING THE ORDER, CHECK WHETHER THE INVENTORY POSSESS THE PRODUCT OR NOT........
//THE BELOW FUNCTIONALITY DOES.......


	@GetMapping("/products")
	public ResponseEntity<List<Inventory>> checkAllProducts(){
		List<Inventory> products= restService.checkAll();
		if(products.isEmpty()||products==null)
			return new ResponseEntity("Sorry! Products not available in inventory!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Inventory>>(products,HttpStatus.OK);
	}




	



//AFTER PLACING THE ORDER UPDATE INVENTORY USING TRANSACTION STATUS.....
//THIS FUNCTIONALITY HAS TO BE WRITTEN IN ARCHANA'S CONTROLLER FUNCTIONALITY FOR TRANSACTION PROCESS....(NOT HERE)

	@PutMapping("/SaveInventory")
	public ResponseEntity<Transaction> update(@RequestBody Transaction transaction){
		
		if(transaction.getStatus().equals("Successfull"))
		{ 
			transaction.getTransactionId();
			Order order= transaction.getOrder();
			List<ManagingCart> managingCarts= order.getManagingCart();
			for (ManagingCart managingCart : managingCarts) {
			int q=managingCart.getQuantity();
				Inventory inventory=managingCart.getInventory();
				int quant=inventory.getQuantity();
				inventory.setQuantity(quant-q);
				restService.save(inventory);				
			}
		}
		
		return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
	}
	
	





//THIS FUNCTIONALITY SPEAKS ABOUT GETTING THE orderID
//(WHENEVER THE CUSTOMER CLICKS ON BUY NOW BUTTON OR PROCEED TO CHECKOUT BUTTON...orderID MUST BE GENERATED)

//THIS IS FOR BUYNOW BUTTON
	
	@PostMapping("/BuyNow")
	public ResponseEntity<Order> generateOrderId1(@RequestBody Order order){
		restService.save1(order);
		return new ResponseEntity<Order>(order,HttpStatus.OK);
	}

//THIS IS FOR PROCEED TO CHECKOUT BUTTON

	@PostMapping("/CheckOut")
	public ResponseEntity<Order> generateOrderId2(@RequestBody Order order){
		restService.save2(order);
		return new ResponseEntity<Order>(order,HttpStatus.OK);
	}
}


	










