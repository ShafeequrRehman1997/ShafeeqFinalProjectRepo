package com.cap.restService;

import java.util.List;

import com.cap.model.Inventory;
import com.cap.model.Order;
import com.cap.model.Transaction;

public interface IRestService {

		//public Inventory updateInventory(Integer transactionId);

		//public void deleteItem(Integer productId);

		public List<Inventory> checkAll();

		//public void update(Inventory inventory);

		public void save(Inventory inventory);

		public void save(Order order);
}
