package com.cap.restService;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.model.Inventory;
import com.cap.model.Order;
import com.cap.model.Transaction;
import com.cap.restDao.IRestDao;
@Service("restService")
@Transactional
public class RestServiceImpl implements IRestService {
	@Autowired
	private IRestDao restDao;
	

/*	@Override
	public Inventory updateInventory(Integer transactionId) {
		return restDao.save(transactionId); 
	}*/

	


	@Override
	public List<Inventory> checkAll() {
		return restDao.findAll(); 
	}


	@Override
	public void save(Inventory inventory) {
		restDao.save(inventory);
		
	}


	@Override
	public void save(Order order) {
		restDao.save(order);
		
	}

}
