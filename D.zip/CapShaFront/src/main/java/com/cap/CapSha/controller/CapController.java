package com.cap.CapSha.controller;

import java.util.Date;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cap.CapSha.model.Inventory;
import com.cap.CapSha.model.Order;
import com.cap.CapSha.model.Transaction;


@Controller
public class CapController {
	
	//@Author Shafeeq
	//Product Page
	@RequestMapping("/product")
	public String getTransactionPage(ModelMap map) {
		return "ProductPage";
	}
	
	//@Author Shafeeq
	//Navigating to shipping details page
	@RequestMapping("/shippingAddressCap")
	public String navigateToShippingDetailsPage() {
		Order order= new Order();
		final String uri="http://localhost:8098/PlacingOrder/api/v1/BuyNow";
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.postForEntity(uri, order, Order.class);
		return "shippingAddressCap";
	}

	//@Author Shafeeq
	//Navigating to shipping details page from cart page
	@RequestMapping("/CheckOut")
	public String proceedFromCart() {
		Order order= new Order();
		final String uri="http://localhost:8098/PlacingOrder/api/v1/BuyNow";
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.postForEntity(uri, order, Order.class);
		return "ShippingAddress";	
	}	
	
}
	
