package placingOrder;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^customer is on the product page$")
	public void customer_is_on_the_product_page() throws Throwable {
	   
	}

	@When("^customer clicks on BUY NOW button$")
	public void customer_clicks_on_BUY_NOW_button() throws Throwable {
	    
	}

	@Then("^navigate to shipping details page$")
	public void navigate_to_shipping_details_page() throws Throwable {
	    
	}

	@When("^customer clicks on ADD TO CART button$")
	public void customer_clicks_on_ADD_TO_CART_button() throws Throwable {
	   
	}

	@Then("^navigate to cart page$")
	public void navigate_to_cart_page() throws Throwable {
	   
	}

	@Given("^customer is on the cart page$")
	public void customer_is_on_the_cart_page() throws Throwable {
	 
	}

	@When("^customer clicks PROCEED NOW button$")
	public void customer_clicks_PROCEED_NOW_button() throws Throwable {
	   
	}
}
