package com.cap.PlacingOrder.restService;

import java.util.List;

import com.cap.PlacingOrder.model.Transaction;

public interface ITransService {

	public List<Transaction> findAll();
	
}
