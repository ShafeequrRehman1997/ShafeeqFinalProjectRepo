package com.cap.PlacingOrder.restService;

import java.util.List;

import com.cap.PlacingOrder.model.Inventory;
import com.cap.PlacingOrder.model.ManagingCart;
import com.cap.PlacingOrder.model.Order;
import com.cap.PlacingOrder.model.Transaction;

public interface IRestService {

		public List<Inventory> checkAll();
		public void save(Inventory inventory); 
		public List<ManagingCart> findcartbyid(int id);
		public Inventory findproductbyid(int cartId);
		public void save(Transaction transaction);
		public void save1(Order order);
		public List<Order> checkAll1();

}
