package com.cap.PlacingOrder.restService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.PlacingOrder.model.Transaction;
import com.cap.PlacingOrder.restDao.TransDao;

@Service("transService")
public class TransServiceImpl implements ITransService{

	@Autowired
	private TransDao transDao;
	
	@Override
	public List<Transaction> findAll() {
		return transDao.findAll();
	}

}
