package com.cap.CapShaBackRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapShaBackRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapShaBackRestApplication.class, args);
	}
}
