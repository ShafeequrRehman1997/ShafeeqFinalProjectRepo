package com.cap.PlacingOrder.restController;


import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.PlacingOrder.model.Inventory;
import com.cap.PlacingOrder.model.ManagingCart;
import com.cap.PlacingOrder.model.Order;
import com.cap.PlacingOrder.model.Transaction;
import com.cap.PlacingOrder.restService.IRestService;
import com.cap.PlacingOrder.restService.ITransService;

@RestController
@RequestMapping("/api/v1")
public class CrudRestCapController {
	
	@Autowired
	private IRestService restService;
	@Autowired
	private ITransService transService;

	
	//@Author Shafeeq
	//checking the availability of products in inventory prior to placing the order
	@GetMapping("/products")
	public ResponseEntity<List<Inventory>> checkAllProducts(){
		List<Inventory> products= restService.checkAll();
		if(products.isEmpty()||products==null)
			return new ResponseEntity("Sorry! Products not available in inventory!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Inventory>>(products,HttpStatus.OK);
	}

	
	//@Author Shafeeq
	//checking all the transactions
	@GetMapping("/trans")
	public ResponseEntity<List<Transaction>> checkAll(){
		List<Transaction> transactions= transService.findAll();
		if(transactions.isEmpty()||transactions==null)
			return new ResponseEntity("Sorry! not available", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Transaction>>(transactions,HttpStatus.OK);
	}


	//@Author Shafeeq
	//updating the inventory using transactionId
	@PutMapping("/SaveInventory") 
	public ResponseEntity<Transaction> update(@RequestBody Transaction transaction){
		restService.save(transaction);
		List<ManagingCart> cart=null;
		if(transaction.getStatus().equals("Successfull"))
		{ 
			transaction.getTransactionId();
			Order order= transaction.getOrder();
			int id=order.getOrderId();
			cart=restService.findcartbyid(id);
			for (ManagingCart managingCart : cart) {
				Inventory product=restService.findproductbyid(managingCart.getCartId());
				product.setQuantity(product.getQuantity()-managingCart.getQuantity());
				restService.save(product);
			}
							
		}
		return new ResponseEntity<Transaction>(transaction,HttpStatus.OK);
	}

	
	//@Author Shafeeq
	//generating orderId when buyNow button is pressed
	@PostMapping("/BuyNow")
	public ResponseEntity<Order> generateOrderId(@RequestBody Order order){
		order.setOrderDate(new Date());
		restService.save1(order);
		return new ResponseEntity<Order>(order,HttpStatus.OK);
	}

	
	//@Author Shafeeq
	//generating orderId when CheckOut button is pressed
	@PostMapping("/CheckOut")
	public ResponseEntity<Order> generateOrderIdd(@RequestBody Order order){
		order.setOrderDate(new Date());
		restService.save1(order);
		return new ResponseEntity<Order>(order,HttpStatus.OK);
	}
	
	
	//@Author Shafeeq
	//To check all the orders
	@GetMapping("/orders")
	public ResponseEntity<List<Order>> checkAllOrders(){
		List<Order> orders= restService.checkAll1();
		if(orders.isEmpty()||orders==null)
			return new ResponseEntity("Sorry! No orders available!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Order>>(orders,HttpStatus.OK);
	}

}
