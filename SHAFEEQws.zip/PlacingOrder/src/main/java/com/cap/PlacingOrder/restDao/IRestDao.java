package com.cap.PlacingOrder.restDao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.PlacingOrder.model.Inventory;
import com.cap.PlacingOrder.model.Order;
import com.cap.PlacingOrder.model.Transaction;

@Repository("restDao")
public interface IRestDao extends JpaRepository<Inventory,Integer> {

}