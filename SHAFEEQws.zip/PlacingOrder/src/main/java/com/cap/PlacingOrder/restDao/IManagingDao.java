package com.cap.PlacingOrder.restDao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.PlacingOrder.model.Inventory;
import com.cap.PlacingOrder.model.ManagingCart;
import com.cap.PlacingOrder.model.Transaction;
@Repository("manaDao")
public interface IManagingDao extends JpaRepository<ManagingCart,Integer> {
	
	@Query("select c from ManagingCart c where c.order.orderId = :id")
	List<ManagingCart> findcartbyid(@Param("id")int id);

}
