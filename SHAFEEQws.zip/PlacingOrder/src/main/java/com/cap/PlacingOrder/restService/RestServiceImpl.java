package com.cap.PlacingOrder.restService;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.PlacingOrder.model.Inventory;
import com.cap.PlacingOrder.model.ManagingCart;
import com.cap.PlacingOrder.model.Order;
import com.cap.PlacingOrder.model.Transaction;
import com.cap.PlacingOrder.restDao.IInvDao;
import com.cap.PlacingOrder.restDao.IManagingDao;
import com.cap.PlacingOrder.restDao.IOrderDao;
import com.cap.PlacingOrder.restDao.IRestDao;
import com.cap.PlacingOrder.restDao.TransDao;
@Service("restService")
@Transactional
public class RestServiceImpl implements IRestService {
	
	@Autowired
	private IRestDao restDao;
	@Autowired
	private  IInvDao invDao;
	@Autowired
	private IManagingDao manaDao;
	@Autowired
	private TransDao transDao;
	@Autowired
	private IOrderDao orderDao;

	@Override
	public List<Inventory> checkAll() {
		return restDao.findAll(); 
	}


	@Override									
	public void save(Inventory inventory) {
		restDao.save(inventory);
	}


	@Override
	public List<ManagingCart> findcartbyid(int id) {
		return manaDao.findcartbyid(id);
	}


	@Override
	public Inventory findproductbyid(int cartId) {
		return invDao.findproductbyid(cartId);
	}


	@Override
	public void save(Transaction transaction) {
		transDao.save(transaction);
	}


	@Override
	public void save1(Order order) {
		orderDao.save(order);
	}


	@Override
	public List<Order> checkAll1() {
		return orderDao.findAll();
	}

}
