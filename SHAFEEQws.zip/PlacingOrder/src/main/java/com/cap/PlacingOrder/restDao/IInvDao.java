package com.cap.PlacingOrder.restDao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.PlacingOrder.model.Inventory;
import com.cap.PlacingOrder.model.Transaction;
@Repository("invDao")
public interface IInvDao extends JpaRepository<Inventory,Integer> {
	
	@Query("select i from Inventory i where i.managingCart.cartId=:id")
	Inventory findproductbyid(@Param("id") int cartId);

}
