package updateInventoryUsingTransactionStatus;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^Transaction status$")
	public void transaction_status() throws Throwable {
	   
	}

	@When("^status is successfull$")
	public void status_is_successfull() throws Throwable {
	   
	}

	@Then("^update the inventory$")
	public void update_the_inventory() throws Throwable {
	    
	}
}
