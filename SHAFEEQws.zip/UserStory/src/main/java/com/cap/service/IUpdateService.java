package com.cap.service;

public interface IUpdateService {

	public void delete(Integer productId);

}
