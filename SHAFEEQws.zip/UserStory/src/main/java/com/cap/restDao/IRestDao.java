package com.cap.restDao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.model.Inventory;


@Repository("restDao")
public interface IRestDao extends JpaRepository<Inventory,Integer> {



}
