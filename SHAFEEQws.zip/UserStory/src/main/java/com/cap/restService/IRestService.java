package com.cap.restService;

import java.util.List;

import com.cap.model.Inventory;
import com.cap.model.Order;

public interface IRestService {

		//public Inventory updateInventory(Integer transactionId);

		//public void deleteItem(Integer productId);

		public List<Inventory> checkAll();

		public void update(Inventory inventory);
}
