package com.cap.controller;


import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cap.model.Inventory;
import com.cap.restService.IRestService;


@RestController
@RequestMapping("/api/v1")
public class CrudRestCapController {
	@Autowired
	private IRestService restService;

	

	/*@PostMapping("/buyNow")
	public String showDetails1(@PathVariable("quantity") Integer quantity) {
		Order order=new Order();
		product.setQuantity(quantity);
		order.setOrderDate(new Date());
		return "shippingAddressCap";
}
	
	@PostMapping("/addToCart")
	public String showDetails2(@PathVariable("quantity") Integer quantity) {
		Order order=new Order();
		product.setQuantity(quantity);
		order.setOrderDate(new Date());
		return "shippingAddressCap";
}

	@DeleteMapping("/remove/{productId}")
	public String removeItemFromCart(@PathVariable("productId") Integer productId) {
	restService.deleteItem(productId);
		return "index";	
	}*/
	
	@GetMapping("/products")
	public ResponseEntity<List<Inventory>> checkAllProducts(){
		List<Inventory> products= restService.checkAll();
		if(products.isEmpty()||products==null)
			return new ResponseEntity("Sorry! Products not available in inventory!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Inventory>>(products,HttpStatus.OK);
	}


	/*@GetMapping("/update/{transactionId}")
	public void updateInventoryUsingTransactionStatus(@PathVariable("transactionId") Integer transactionId) {
		product=restService.updateInventory(transactionId);
}*/
	
	@PostMapping("/SaveInventory")
	public String showPilotDetails(@Valid @ModelAttribute("inventory") Inventory inventory, BindingResult result) {
		
			if(!result.hasErrors()) {
				
				restService.update(inventory);
			//System.out.println(inventory);
		
				inventory=null;
		
	}
		return "redirect:/";
}
	
}













