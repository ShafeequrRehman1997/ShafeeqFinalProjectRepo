package com.cap.CapSha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapShaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapShaApplication.class, args);
	}
}
