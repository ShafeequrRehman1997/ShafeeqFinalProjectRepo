package org.cap.pilot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PilotAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(PilotAppApplication.class, args);
	}
}
