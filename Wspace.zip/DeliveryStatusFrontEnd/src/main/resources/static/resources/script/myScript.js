function showInputs(){
	if(document.getElementById('radio1').checked){
		document.getElementById('online').style.display='block';
		document.getElementById('card').style.display='none';
	}
	else if(document.getElementById('radio2').checked){
		document.getElementById('online').style.display='none';
		document.getElementById('card').style.display='block';
	}
	else{
		document.getElementById('online').style.display='none';
		document.getElementById('card').style.display='none';
	}
}

window.onload= function(){
	document.getElementById('online').style.display='none';
	document.getElementById('card').style.display='none';
}