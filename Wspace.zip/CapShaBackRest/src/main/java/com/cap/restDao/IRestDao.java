package com.cap.restDao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.model.Inventory;
import com.cap.model.Order;
import com.cap.model.Transaction;


@Repository("restDao")
public interface IRestDao extends JpaRepository<Inventory,Integer> {
	//shravya
	/*@Query("select i from Inventory i where i.managingCart.cartId=:id")
	Inventory findproductbyid(@Param("id") Integer cartId);*/
	
	//varun
	/*@Query("select m from ManagingCart m where m.customers.custId=:customerId")
	public List<ManagingCart> findProduct(@Param("customerId") int customerId);*/
	
	
	
	
	@Query("select o from Order o where o.customers.cartId=:id")
	public void save(@Param("id") Order order);
	

}