package com.capgemini.delivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryStatusApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryStatusApplication.class, args);
	}
}
