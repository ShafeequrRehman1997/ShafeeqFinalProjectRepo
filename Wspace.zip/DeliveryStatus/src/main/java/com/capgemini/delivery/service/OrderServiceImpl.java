package com.capgemini.delivery.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.delivery.dao.InventoryDao;
import com.capgemini.delivery.dao.ManagingDao;
import com.capgemini.delivery.dao.OrderDao;
import com.capgemini.delivery.model.Inventory;
import com.capgemini.delivery.model.ManagingCart;
import com.capgemini.delivery.model.Order;
@Service("orderService")
@Transactional
public class OrderServiceImpl implements OrderService{

	@Autowired
	private OrderDao orderDao;
	@Autowired
	private ManagingDao managingDao;
	@Autowired
    private InventoryDao inventoryDao;

	@Override
	public void save(Order feedback) {
		orderDao.save(feedback);
		
	}


	@Override
	public List<Order> getAll() {
		return orderDao.findAll();
	
	}


	@Override
	public  Order getOne(Integer orderId) {
		// TODO Auto-generated method stub
		return orderDao.getOne(orderId);
		 
	}


	@Override
	public void delete(Integer fid) {
		// TODO Auto-generated method stub
		orderDao.deleteById(fid);
	}


	@Override
	public List<ManagingCart> findcartbyid(int orderId) {
		// TODO Auto-generated method stub
		return managingDao.findcartbyid(orderId);
	}


	@Override
	public Inventory findproductbyid(int cartId) {
		// TODO Auto-generated method stub
		return inventoryDao.findproductbyid(cartId);
	}


	@Override
	public void save(Inventory product) {
		// TODO Auto-generated method stub
		inventoryDao.save(product);
	}

/*
	@Override
	public void updateInventory(int cartId, int qty) {
		
		
		
		inventoryDao.updateQty(cartId,qty);
	}
*/

	

	
	
}
