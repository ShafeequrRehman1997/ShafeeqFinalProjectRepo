package com.capgemini.delivery.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name="caporder")

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
 

public class Order{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	
	
	@OneToMany(targetEntity = ManagingCart.class, mappedBy = "order")
	private  List<ManagingCart> managingCart;
	
	private Date orderDate;
	private Date deliveredDate;
	
	
	
	private String deliveryStatus;
	
	
	
	
	public int getOrderId() {
		return orderId;
	}




	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}




	/*public List<ManagingCart> getManagingCart() {
		return managingCart;
	}*/




	public void setManagingCart(List<ManagingCart> managingCart) {
		this.managingCart = managingCart;
	}




	public Order(int orderId, List<ManagingCart> managingCart, Date orderDate, Date deliveredDate,
			String deliveryStatus) {
		super();
		this.orderId = orderId;
		this.managingCart = managingCart;
		this.orderDate = orderDate;
		this.deliveredDate = deliveredDate;
		this.deliveryStatus = deliveryStatus;
	}




	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", managingCart=" + managingCart + ", orderDate=" + orderDate
				+ ", deliveredDate=" + deliveredDate + ", deliveryStatus=" + deliveryStatus + "]";
	}




	public Date getOrderDate() {
		return orderDate;
	}




	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}




	public Date getDeliveredDate() {
		return deliveredDate;
	}




	public void setDeliveredDate(Date deliveredDate) {
		this.deliveredDate = deliveredDate;
	}




	public String getDeliveryStatus() {
		return deliveryStatus;
	}




	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}




	public Order() {
		super();
	}
	
	
	
	
	
	
	

	
	
	
}
