package com.cap.dao;

public interface IUpdateDao {

	public void delete(Integer productId);

}
