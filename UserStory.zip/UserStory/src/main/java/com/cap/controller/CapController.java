package com.cap.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cap.model.Inventory;
import com.cap.service.IUpdateService;

@Controller
public class CapController {
	
	@Autowired
	private IUpdateService updateService;
	private Inventory product;
		
	@RequestMapping("/buyNow")
	public String navigateToShippingDetailsPage() {
		final String uri="http://localhost:8087/CapRestApp/api/v1/"; //temporary url
		RestTemplate restTemplate=new RestTemplate(); //RestTemplate
		//
		return "shippingAddress";
	}
	
	
	@RequestMapping("/addToCart")
	public String navigateToCartPage() {
		final String uri="http://localhost:8087/CapRestApp/api/v1/products"; //temporary url
		RestTemplate restTemplate=new RestTemplate(); //RestTemplate
		//
		return "index";
	}
	
	@RequestMapping("/remove/{productId}")
	public String removeItemFromCart(@PathVariable("productId") Integer productId) {
		final String uri="http://localhost:8087/CapRestApp/api/v1/products/{productId}"; //temporary url
		RestTemplate restTemplate=new RestTemplate(); //RestTemplate
		//
		return "index";	
	}
	
	@RequestMapping("/CheckOut")
	public String proceedFromCart() {
		final String uri="http://localhost:8087/CapRestApp/api/v1/"; //temporary url
		RestTemplate restTemplate=new RestTemplate(); //RestTemplate
		//
		return "ShippingAddress";	
	}	
	
	@RequestMapping("/ContinueShopping")
	public String continueShopping() {
		final String uri="http://localhost:8087/CapRestApp/api/v1/"; //temporary url
		RestTemplate restTemplate=new RestTemplate(); //RestTemplate
		//
		return "ProductPage";
	}
}
	
