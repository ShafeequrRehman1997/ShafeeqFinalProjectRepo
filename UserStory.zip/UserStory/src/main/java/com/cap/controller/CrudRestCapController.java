package com.cap.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cap.model.Inventory;
import com.cap.model.Order;
import com.cap.restService.IRestService;

import com.cap.service.UpdateService;

@RestController
//@RequestMapping("/api/v1")
public class CrudRestCapController {
	@Autowired
	private IRestService restService;
	private Inventory product;
	/*@GetMapping("/products")
	public ResponseEntity<List<Inventory>> getAllProducts(){
		List<Inventory> products= restService.getAll();
		if(products.isEmpty()||products==null)
			return new ResponseEntity("Sorry! Product details not available!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Inventory>>(products,HttpStatus.OK);
	}*/
	
/*	@RequestMapping("/remove/{productId}")
	public String removeItemFromCart(@PathVariable("productId") Integer productId) {
		//final String uri="http://localhost:8087/CapRestApp/api/v1/products/{productId}"; //temporary url
		//RestTemplate restTemplate=new RestTemplate(); //RestTemplate
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("productId", productId);
		//restTemplate.delete(uri,params);
		
		updateService.delete(productId);
		return "index";	
	}*/
	
/*	@DeleteMapping("/products/{productId}")
	public void removeItemFromCart(@PathVariable("productId") Integer productId) {
		
		restService.delete(productId);
		
	}*/
	
	/*@GetMapping("/products/{orderId}")
	public ResponseEntity<List<Order>> saveDet(@PathVariable("orderId") Integer orderId){
		List<Order> orders= restService.saveOrderDetails(orderId);
		if(orders.isEmpty()||orders==null)
			return new ResponseEntity("Sorry! Order is not available!", HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Order>>(orders,HttpStatus.OK);
	}*/
	
	@PostMapping("/buyNow")
	public String showPilotDetails(@PathVariable("quantity") Integer quantity) {
		Order order=new Order();
	//	order.setQuantity
		order.setOrderDate(new Date());
		return "shippingAddressCap";
}
	@PutMapping("/update/{orderId}")
	public String updateInventoryUsingTransactionStatus(@PathVariable("orderId") Integer orderId) {
		product=restService.updateInventory(orderId);
		//System.out.println(pilot);
		return "redirect:/";	
}
}













