package com.cap.restService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.model.Inventory;
import com.cap.model.Order;
import com.cap.restDao.IRestDao;
@Service("restService")
public class RestServiceImpl implements IRestService {
	@Autowired
	private IRestDao restDao;

	

	@Override
	public Inventory updateInventory(Integer orderId) {
		return restDao.getOne(orderId);
	}

}
