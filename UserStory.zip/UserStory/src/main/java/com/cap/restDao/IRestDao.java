package com.cap.restDao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.model.Inventory;
import com.cap.model.Order;

@Repository("restDao")
public interface IRestDao extends JpaRepository<Inventory,Integer> {


}
